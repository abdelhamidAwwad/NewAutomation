# demo-nop-commerce
Test Automation framework using Java, TestNG, Cucumber, Gherkin
Json file is used to submit and change the credentials for Register and login features
Test execution Report and screenshots is provided with the project
